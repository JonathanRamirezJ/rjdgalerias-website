<?php
 header( 'Location: http://www.google.com/a/rjdgalerias.com');
?>


